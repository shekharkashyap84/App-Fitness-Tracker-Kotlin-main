package co.tiagoaguiar.fitnesstracker

interface OnItemClickListener {
    fun onClick(id: Int)
}